
import UIKit
import  GoogleSignIn

class ViewController: UIViewController, GIDSignInUIDelegate, GIDSignInDelegate {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        GIDSignIn.sharedInstance().uiDelegate = self
        GIDSignIn.sharedInstance().delegate = self
        
    }
    
    @IBAction func didTapLogin(_ sender: UIButton) {
        
        GIDSignIn.sharedInstance().signIn()
        
    }
    
    // Present a view that prompts the user to sign in with Google
    private func signIn(signIn: GIDSignIn!,
                        presentViewController viewController: UIViewController!) {
        self.present(viewController, animated: true, completion: nil)
    }
    
    // Dismiss the "Sign in with Google" view
    func sign(_ signIn: GIDSignIn!,
              dismiss viewController: UIViewController!) {
        self.dismiss(animated: true, completion: nil)
    }
    
    //completed sign In
    public func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!, withError error: Error!) {
        
        if (error == nil) {
            
            let userId = GIDSignIn.sharedInstance().currentUser.userID!
            let fullName = GIDSignIn.sharedInstance().currentUser.profile.name!
            let familyName = GIDSignIn.sharedInstance().currentUser.profile.familyName!
            let givenName = GIDSignIn.sharedInstance().currentUser.profile.givenName!
            let email = GIDSignIn.sharedInstance().currentUser.profile.email!
            
            print("User Id: " + userId + "\nFullName: " + fullName + "\nfamilyName: " + familyName + "\ngivenName: " + givenName + "\nemail: " + email)
            
        } else {
            print("\(error.localizedDescription)")
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}

